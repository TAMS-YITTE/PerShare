"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[4183],{44183:function(t,e,r){r.r(e),r.d(e,{PhCaretDown:function(){return c}}),r(82465);var l=r(2612),o=r(6433),a=r(55862),i=r(63721),s=r(76044),h=Object.defineProperty,p=Object.getOwnPropertyDescriptor,n=(t,e,r,l)=>{for(var o,a=l>1?void 0:l?p(e,r):e,i=t.length-1;i>=0;i--)(o=t[i])&&(a=(l?o(e,r,a):o(a))||a);return l&&a&&h(e,r,a),a};let c=class extends o.oi{constructor(){super(...arguments),this.size="1em",this.weight="regular",this.color="currentColor",this.mirrored=!1}render(){var t;return(0,l.dy)`<svg
      xmlns="http://www.w3.org/2000/svg"
      width="${this.size}"
      height="${this.size}"
      fill="${this.color}"
      viewBox="0 0 256 256"
      transform=${this.mirrored?"scale(-1, 1)":null}
    >
      ${c.weightsMap.get(null!=(t=this.weight)?t:"regular")}
    </svg>`}};c.weightsMap=new Map([["thin",(0,l.YP)`<path d="M210.83,98.83l-80,80a4,4,0,0,1-5.66,0l-80-80a4,4,0,0,1,5.66-5.66L128,170.34l77.17-77.17a4,4,0,1,1,5.66,5.66Z"/>`],["light",(0,l.YP)`<path d="M212.24,100.24l-80,80a6,6,0,0,1-8.48,0l-80-80a6,6,0,0,1,8.48-8.48L128,167.51l75.76-75.75a6,6,0,0,1,8.48,8.48Z"/>`],["regular",(0,l.YP)`<path d="M213.66,101.66l-80,80a8,8,0,0,1-11.32,0l-80-80A8,8,0,0,1,53.66,90.34L128,164.69l74.34-74.35a8,8,0,0,1,11.32,11.32Z"/>`],["bold",(0,l.YP)`<path d="M216.49,104.49l-80,80a12,12,0,0,1-17,0l-80-80a12,12,0,0,1,17-17L128,159l71.51-71.52a12,12,0,0,1,17,17Z"/>`],["fill",(0,l.YP)`<path d="M213.66,101.66l-80,80a8,8,0,0,1-11.32,0l-80-80A8,8,0,0,1,48,88H208a8,8,0,0,1,5.66,13.66Z"/>`],["duotone",(0,l.YP)`<path d="M208,96l-80,80L48,96Z" opacity="0.2"/><path d="M215.39,92.94A8,8,0,0,0,208,88H48a8,8,0,0,0-5.66,13.66l80,80a8,8,0,0,0,11.32,0l80-80A8,8,0,0,0,215.39,92.94ZM128,164.69,67.31,104H188.69Z"/>`]]),c.styles=(0,s.iv)`
    :host {
      display: contents;
    }
  `,n([(0,i.C)({type:String,reflect:!0})],c.prototype,"size",2),n([(0,i.C)({type:String,reflect:!0})],c.prototype,"weight",2),n([(0,i.C)({type:String,reflect:!0})],c.prototype,"color",2),n([(0,i.C)({type:Boolean,reflect:!0})],c.prototype,"mirrored",2),c=n([(0,a.M)("ph-caret-down")],c)}}]);